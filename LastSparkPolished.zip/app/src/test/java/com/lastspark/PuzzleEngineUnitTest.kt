package com.lastspark

import com.lastspark.engine.puzzle.PuzzleEngine
import org.junit.Assert.assertEquals
import org.junit.Test

class PuzzleEngineUnitTest {
    @Test
    fun testLogicGateSuccess() {
        val pe = PuzzleEngine()
        val res = pe.tryLogicGate(7,7)
        assertEquals(com.lastspark.engine.puzzle.PuzzleResult.SOLVED, res)
    }
}
