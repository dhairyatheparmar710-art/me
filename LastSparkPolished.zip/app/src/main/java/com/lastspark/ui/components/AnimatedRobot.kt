package com.lastspark.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Composable
fun AnimatedRobot(modifier: Modifier = Modifier) {
    val infinite = rememberInfiniteTransition()
    val bob by infinite.animateFloat(
        initialValue = -6f,
        targetValue = 6f,
        animationSpec = infiniteRepeatable(tween(1000, easing = LinearEasing), RepeatMode.Reverse)
    )
    Canvas(modifier = modifier.size(120.dp)) {
        val cx = size.width/2
        val cy = size.height/2 + bob
        drawCircle(Color(0xFF00E5FF), radius = size.minDimension*0.25f, center = Offset(cx, cy))
        // simple eye
        drawCircle(Color.Black, radius = 8f, center = Offset(cx - 12f, cy - 6f))
        drawCircle(Color.Black, radius = 8f, center = Offset(cx + 12f, cy - 6f))
    }
}
