package com.lastspark.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.material3.OutlinedTextField
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.lastspark.engine.learn.CSharpInterpreter
import com.lastspark.ui.components.CRTEffect
import com.lastspark.ui.components.AnimatedRobot

@Composable
fun TerminalScreen(onNext: () -> Unit) {
    var input by remember { mutableStateOf("") }
    var output by remember { mutableStateOf("Welcome. Type 'help' for lesson.") }
    val interp = remember { CSharpInterpreter() }

    CRTEffect {
        Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                AnimatedRobot()
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text("Retro Terminal (CRT)")
                    OutlinedTextField(value = input, onValueChange = { input = it }, label = { Text("Enter command or code") })
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(onClick = { output = interp.run(input) }) { Text("Run") }
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
            Text("Output:")
            Spacer(modifier = Modifier.height(6.dp))
            Text(output)
            Spacer(modifier = Modifier.height(20.dp))
            Button(onClick = onNext) { Text("Continue to Puzzle") }
        }
    }
}
