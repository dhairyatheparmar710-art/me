package com.lastspark.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.drawscope.withTransform

@Composable
fun CRTEffect(content: @Composable () -> Unit) {
    Box(modifier = Modifier.fillMaxSize()) {
        content()
        Canvas(modifier = Modifier.fillMaxSize()) {
            // simple translucent vignette
            drawRect(Color(0x22000000))
            // scanlines
            val lineHeight = 6f
            var y = 0f
            while (y < size.height) {
                drawRect(Color(0x11000000), topLeft = androidx.compose.ui.geometry.Offset(0f, y), size = Size(size.width, 2f))
                y += lineHeight
            }
        }
    }
}
