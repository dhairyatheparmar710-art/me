package com.lastspark.ui

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.rememberNavController
import androidx.navigation.compose.composable
import com.lastspark.ui.screens.*

@Composable
fun AppNavHost() {
    val nav = rememberNavController()
    NavHost(navController = nav, startDestination = "home") {
        composable("home") { HomeScreen(onStart = { nav.navigate("chapter1") }, onSkins = { nav.navigate("skins") }) }
        composable("skins") { SkinScreen(onBack = { nav.popBackStack() }, onApply = { skin -> nav.popBackStack() }) }
        composable("chapter1") { ChapterScreen(title = "Chapter 1", onNext = { nav.navigate("terminal") }) }
        composable("terminal") { TerminalScreen(onNext = { nav.navigate("puzzle") }) }
        composable("puzzle") { PuzzleScreen(onSolved = { nav.navigate("naming") }) }
        composable("naming") { NamingScreen(onNamed = { name -> nav.navigate("ending/" + name) }) }
        composable("ending/{name}") { backStackEntry ->
            val name = backStackEntry.arguments?.getString("name") ?: "Unit"
            EndingScreen(playerName = name, navController = nav)
        }
        composable("aperture") { ApertureEasterScreen() }
    }
}
