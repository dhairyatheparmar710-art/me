package com.lastspark

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.lastspark.ui.AppNavHost
import com.lastspark.ui.theme.LastSparkTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            LastSparkTheme {
                AppNavHost()
            }
        }
    }
}
